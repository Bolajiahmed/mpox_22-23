```python
!pip install pandas
!pip install numpy
!pip install seaborn
!pip install matplotlib
```

    Defaulting to user installation because normal site-packages is not writeable
    Requirement already satisfied: pandas in c:\programdata\anaconda3\lib\site-packages (2.2.2)
    Requirement already satisfied: numpy>=1.26.0 in c:\programdata\anaconda3\lib\site-packages (from pandas) (1.26.4)
    Requirement already satisfied: python-dateutil>=2.8.2 in c:\programdata\anaconda3\lib\site-packages (from pandas) (2.9.0.post0)
    Requirement already satisfied: pytz>=2020.1 in c:\programdata\anaconda3\lib\site-packages (from pandas) (2024.1)
    Requirement already satisfied: tzdata>=2022.7 in c:\programdata\anaconda3\lib\site-packages (from pandas) (2023.3)
    Requirement already satisfied: six>=1.5 in c:\programdata\anaconda3\lib\site-packages (from python-dateutil>=2.8.2->pandas) (1.16.0)
    Defaulting to user installation because normal site-packages is not writeable
    Requirement already satisfied: numpy in c:\programdata\anaconda3\lib\site-packages (1.26.4)
    Defaulting to user installation because normal site-packages is not writeable
    Requirement already satisfied: seaborn in c:\programdata\anaconda3\lib\site-packages (0.13.2)
    Requirement already satisfied: numpy!=1.24.0,>=1.20 in c:\programdata\anaconda3\lib\site-packages (from seaborn) (1.26.4)
    Requirement already satisfied: pandas>=1.2 in c:\programdata\anaconda3\lib\site-packages (from seaborn) (2.2.2)
    Requirement already satisfied: matplotlib!=3.6.1,>=3.4 in c:\programdata\anaconda3\lib\site-packages (from seaborn) (3.8.4)
    Requirement already satisfied: contourpy>=1.0.1 in c:\programdata\anaconda3\lib\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (1.2.0)
    Requirement already satisfied: cycler>=0.10 in c:\programdata\anaconda3\lib\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (0.11.0)
    Requirement already satisfied: fonttools>=4.22.0 in c:\programdata\anaconda3\lib\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (4.51.0)
    Requirement already satisfied: kiwisolver>=1.3.1 in c:\programdata\anaconda3\lib\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (1.4.4)
    Requirement already satisfied: packaging>=20.0 in c:\programdata\anaconda3\lib\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (23.2)
    Requirement already satisfied: pillow>=8 in c:\programdata\anaconda3\lib\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (10.3.0)
    Requirement already satisfied: pyparsing>=2.3.1 in c:\programdata\anaconda3\lib\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (3.0.9)
    Requirement already satisfied: python-dateutil>=2.7 in c:\programdata\anaconda3\lib\site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (2.9.0.post0)
    Requirement already satisfied: pytz>=2020.1 in c:\programdata\anaconda3\lib\site-packages (from pandas>=1.2->seaborn) (2024.1)
    Requirement already satisfied: tzdata>=2022.7 in c:\programdata\anaconda3\lib\site-packages (from pandas>=1.2->seaborn) (2023.3)
    Requirement already satisfied: six>=1.5 in c:\programdata\anaconda3\lib\site-packages (from python-dateutil>=2.7->matplotlib!=3.6.1,>=3.4->seaborn) (1.16.0)
    Defaulting to user installation because normal site-packages is not writeable
    Requirement already satisfied: matplotlib in c:\programdata\anaconda3\lib\site-packages (3.8.4)
    Requirement already satisfied: contourpy>=1.0.1 in c:\programdata\anaconda3\lib\site-packages (from matplotlib) (1.2.0)
    Requirement already satisfied: cycler>=0.10 in c:\programdata\anaconda3\lib\site-packages (from matplotlib) (0.11.0)
    Requirement already satisfied: fonttools>=4.22.0 in c:\programdata\anaconda3\lib\site-packages (from matplotlib) (4.51.0)
    Requirement already satisfied: kiwisolver>=1.3.1 in c:\programdata\anaconda3\lib\site-packages (from matplotlib) (1.4.4)
    Requirement already satisfied: numpy>=1.21 in c:\programdata\anaconda3\lib\site-packages (from matplotlib) (1.26.4)
    Requirement already satisfied: packaging>=20.0 in c:\programdata\anaconda3\lib\site-packages (from matplotlib) (23.2)
    Requirement already satisfied: pillow>=8 in c:\programdata\anaconda3\lib\site-packages (from matplotlib) (10.3.0)
    Requirement already satisfied: pyparsing>=2.3.1 in c:\programdata\anaconda3\lib\site-packages (from matplotlib) (3.0.9)
    Requirement already satisfied: python-dateutil>=2.7 in c:\programdata\anaconda3\lib\site-packages (from matplotlib) (2.9.0.post0)
    Requirement already satisfied: six>=1.5 in c:\programdata\anaconda3\lib\site-packages (from python-dateutil>=2.7->matplotlib) (1.16.0)
    


```python
import pandas as pd
```


```python
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
```


```python
pd.read_csv(r"C:\Users\44789\OneDrive\Documents\OwidMpoxData.csv")
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>location</th>
      <th>iso_code</th>
      <th>date</th>
      <th>total_cases</th>
      <th>total_deaths</th>
      <th>new_cases</th>
      <th>new_deaths</th>
      <th>new_cases_smoothed</th>
      <th>new_deaths_smoothed</th>
      <th>new_cases_per_million</th>
      <th>total_cases_per_million</th>
      <th>new_cases_smoothed_per_million</th>
      <th>new_deaths_per_million</th>
      <th>total_deaths_per_million</th>
      <th>new_deaths_smoothed_per_million</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Africa</td>
      <td>OWID_AFR</td>
      <td>01/05/2022</td>
      <td>27</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0.29</td>
      <td>0.00</td>
      <td>0.000</td>
      <td>0.019</td>
      <td>0.000</td>
      <td>0.0</td>
      <td>0.00140</td>
      <td>0.00000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Africa</td>
      <td>OWID_AFR</td>
      <td>02/05/2022</td>
      <td>27</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0.29</td>
      <td>0.00</td>
      <td>0.000</td>
      <td>0.019</td>
      <td>0.000</td>
      <td>0.0</td>
      <td>0.00140</td>
      <td>0.00000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Africa</td>
      <td>OWID_AFR</td>
      <td>03/05/2022</td>
      <td>27</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0.29</td>
      <td>0.00</td>
      <td>0.000</td>
      <td>0.019</td>
      <td>0.000</td>
      <td>0.0</td>
      <td>0.00140</td>
      <td>0.00000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Africa</td>
      <td>OWID_AFR</td>
      <td>04/05/2022</td>
      <td>27</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0.29</td>
      <td>0.00</td>
      <td>0.000</td>
      <td>0.019</td>
      <td>0.000</td>
      <td>0.0</td>
      <td>0.00140</td>
      <td>0.00000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Africa</td>
      <td>OWID_AFR</td>
      <td>05/05/2022</td>
      <td>27</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0.29</td>
      <td>0.00</td>
      <td>0.000</td>
      <td>0.019</td>
      <td>0.000</td>
      <td>0.0</td>
      <td>0.00140</td>
      <td>0.00000</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>33661</th>
      <td>World</td>
      <td>OWID_WRL</td>
      <td>05/05/2023</td>
      <td>87365</td>
      <td>140</td>
      <td>4</td>
      <td>0</td>
      <td>16.86</td>
      <td>1.71</td>
      <td>0.001</td>
      <td>10.955</td>
      <td>0.002</td>
      <td>0.0</td>
      <td>0.01755</td>
      <td>0.00021</td>
    </tr>
    <tr>
      <th>33662</th>
      <td>World</td>
      <td>OWID_WRL</td>
      <td>06/05/2023</td>
      <td>87365</td>
      <td>140</td>
      <td>0</td>
      <td>0</td>
      <td>16.86</td>
      <td>1.71</td>
      <td>0.000</td>
      <td>10.955</td>
      <td>0.002</td>
      <td>0.0</td>
      <td>0.01755</td>
      <td>0.00021</td>
    </tr>
    <tr>
      <th>33663</th>
      <td>World</td>
      <td>OWID_WRL</td>
      <td>07/05/2023</td>
      <td>87376</td>
      <td>140</td>
      <td>11</td>
      <td>0</td>
      <td>15.00</td>
      <td>1.71</td>
      <td>0.001</td>
      <td>10.956</td>
      <td>0.002</td>
      <td>0.0</td>
      <td>0.01755</td>
      <td>0.00021</td>
    </tr>
    <tr>
      <th>33664</th>
      <td>World</td>
      <td>OWID_WRL</td>
      <td>08/05/2023</td>
      <td>87376</td>
      <td>140</td>
      <td>0</td>
      <td>0</td>
      <td>12.43</td>
      <td>1.71</td>
      <td>0.000</td>
      <td>10.956</td>
      <td>0.002</td>
      <td>0.0</td>
      <td>0.01755</td>
      <td>0.00021</td>
    </tr>
    <tr>
      <th>33665</th>
      <td>World</td>
      <td>OWID_WRL</td>
      <td>09/05/2023</td>
      <td>87376</td>
      <td>140</td>
      <td>0</td>
      <td>0</td>
      <td>10.57</td>
      <td>1.71</td>
      <td>0.000</td>
      <td>10.956</td>
      <td>0.001</td>
      <td>0.0</td>
      <td>0.01755</td>
      <td>0.00021</td>
    </tr>
  </tbody>
</table>
<p>33666 rows × 15 columns</p>
</div>




```python
dt1=pd.read_csv(r"C:\Users\44789\OneDrive\Documents\OwidMpoxData.csv")
```


```python
dt1.columns
```




    Index(['location', 'iso_code', 'date', 'total_cases', 'total_deaths',
           'new_cases', 'new_deaths', 'new_cases_smoothed', 'new_deaths_smoothed',
           'new_cases_per_million', 'total_cases_per_million',
           'new_cases_smoothed_per_million', 'new_deaths_per_million',
           'total_deaths_per_million', 'new_deaths_smoothed_per_million'],
          dtype='object')




```python
dt1.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>total_cases</th>
      <th>total_deaths</th>
      <th>new_cases</th>
      <th>new_deaths</th>
      <th>new_cases_smoothed</th>
      <th>new_deaths_smoothed</th>
      <th>new_cases_per_million</th>
      <th>total_cases_per_million</th>
      <th>new_cases_smoothed_per_million</th>
      <th>new_deaths_per_million</th>
      <th>total_deaths_per_million</th>
      <th>new_deaths_smoothed_per_million</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>33666.000000</td>
      <td>33666.000000</td>
      <td>33666.000000</td>
      <td>33666.000000</td>
      <td>33666.000000</td>
      <td>33666.000000</td>
      <td>33666.000000</td>
      <td>33666.000000</td>
      <td>33666.000000</td>
      <td>33666.000000</td>
      <td>33666.000000</td>
      <td>33666.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1938.869809</td>
      <td>1.708489</td>
      <td>7.783728</td>
      <td>0.012297</td>
      <td>7.781165</td>
      <td>0.012120</td>
      <td>0.078259</td>
      <td>19.725986</td>
      <td>0.077846</td>
      <td>0.000081</td>
      <td>0.011195</td>
      <td>0.000080</td>
    </tr>
    <tr>
      <th>std</th>
      <td>8459.303549</td>
      <td>8.497967</td>
      <td>63.686045</td>
      <td>0.216703</td>
      <td>49.289572</td>
      <td>0.088667</td>
      <td>0.923805</td>
      <td>30.910935</td>
      <td>0.394291</td>
      <td>0.002657</td>
      <td>0.041827</td>
      <td>0.000991</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>4.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.680000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>21.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>4.878000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>257.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.570000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>29.362250</td>
      <td>0.025000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>87376.000000</td>
      <td>140.000000</td>
      <td>1802.000000</td>
      <td>12.000000</td>
      <td>1089.140000</td>
      <td>1.710000</td>
      <td>91.808000</td>
      <td>183.615000</td>
      <td>17.443000</td>
      <td>0.226830</td>
      <td>0.587380</td>
      <td>0.031760</td>
    </tr>
  </tbody>
</table>
</div>




```python
dt1.isnull().sum()
```




    location                           0
    iso_code                           0
    date                               0
    total_cases                        0
    total_deaths                       0
    new_cases                          0
    new_deaths                         0
    new_cases_smoothed                 0
    new_deaths_smoothed                0
    new_cases_per_million              0
    total_cases_per_million            0
    new_cases_smoothed_per_million     0
    new_deaths_per_million             0
    total_deaths_per_million           0
    new_deaths_smoothed_per_million    0
    dtype: int64




```python
dt1.columns
```




    Index(['location', 'iso_code', 'date', 'total_cases', 'total_deaths',
           'new_cases', 'new_deaths', 'new_cases_smoothed', 'new_deaths_smoothed',
           'new_cases_per_million', 'total_cases_per_million',
           'new_cases_smoothed_per_million', 'new_deaths_per_million',
           'total_deaths_per_million', 'new_deaths_smoothed_per_million'],
          dtype='object')




```python
sns.relplot(x='new_cases_smoothed_per_million', y='new_deaths_smoothed_per_million', data=dt1)
```




    <seaborn.axisgrid.FacetGrid at 0x241463cffe0>




    
![png](output_9_1.png)
    



```python
sns.pairplot(dt1)
```




    <seaborn.axisgrid.PairGrid at 0x1c9273a2ae0>




    
![png](output_10_1.png)
    



```python
dt1.columns
```




    Index(['location', 'iso_code', 'date', 'total_cases', 'total_deaths',
           'new_cases', 'new_deaths', 'new_cases_smoothed', 'new_deaths_smoothed',
           'new_cases_per_million', 'total_cases_per_million',
           'new_cases_smoothed_per_million', 'new_deaths_per_million',
           'total_deaths_per_million', 'new_deaths_smoothed_per_million'],
          dtype='object')




```python
sns.relplot(x='new_cases_smoothed_per_million', y='new_deaths_per_million', kind='line', data=dt1)
```




    <seaborn.axisgrid.FacetGrid at 0x1c955a91040>




    
![png](output_12_1.png)
    



```python
sns.catplot(x='total_cases', y='total_deaths', data=dt1)
```




    <seaborn.axisgrid.FacetGrid at 0x1c954f7c3b0>




    
![png](output_13_1.png)
    



```python
!pip install geopandas 
```

    Defaulting to user installation because normal site-packages is not writeable
    Requirement already satisfied: geopandas in c:\users\44789\appdata\roaming\python\python312\site-packages (1.0.1)
    Requirement already satisfied: numpy>=1.22 in c:\programdata\anaconda3\lib\site-packages (from geopandas) (1.26.4)
    Requirement already satisfied: pyogrio>=0.7.2 in c:\users\44789\appdata\roaming\python\python312\site-packages (from geopandas) (0.9.0)
    Requirement already satisfied: packaging in c:\programdata\anaconda3\lib\site-packages (from geopandas) (23.2)
    Requirement already satisfied: pandas>=1.4.0 in c:\programdata\anaconda3\lib\site-packages (from geopandas) (2.2.2)
    Requirement already satisfied: pyproj>=3.3.0 in c:\users\44789\appdata\roaming\python\python312\site-packages (from geopandas) (3.6.1)
    Requirement already satisfied: shapely>=2.0.0 in c:\users\44789\appdata\roaming\python\python312\site-packages (from geopandas) (2.0.6)
    Requirement already satisfied: python-dateutil>=2.8.2 in c:\programdata\anaconda3\lib\site-packages (from pandas>=1.4.0->geopandas) (2.9.0.post0)
    Requirement already satisfied: pytz>=2020.1 in c:\programdata\anaconda3\lib\site-packages (from pandas>=1.4.0->geopandas) (2024.1)
    Requirement already satisfied: tzdata>=2022.7 in c:\programdata\anaconda3\lib\site-packages (from pandas>=1.4.0->geopandas) (2023.3)
    Requirement already satisfied: certifi in c:\programdata\anaconda3\lib\site-packages (from pyogrio>=0.7.2->geopandas) (2024.6.2)
    Requirement already satisfied: six>=1.5 in c:\programdata\anaconda3\lib\site-packages (from python-dateutil>=2.8.2->pandas>=1.4.0->geopandas) (1.16.0)
    


```python
from mpl_toolkits.axes_grid1 import make_axes_locatable
```


```python
dt1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>location</th>
      <th>iso_code</th>
      <th>date</th>
      <th>total_cases</th>
      <th>total_deaths</th>
      <th>new_cases</th>
      <th>new_deaths</th>
      <th>new_cases_smoothed</th>
      <th>new_deaths_smoothed</th>
      <th>new_cases_per_million</th>
      <th>total_cases_per_million</th>
      <th>new_cases_smoothed_per_million</th>
      <th>new_deaths_per_million</th>
      <th>total_deaths_per_million</th>
      <th>new_deaths_smoothed_per_million</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Africa</td>
      <td>OWID_AFR</td>
      <td>01/05/2022</td>
      <td>27</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0.29</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.019</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0014</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Africa</td>
      <td>OWID_AFR</td>
      <td>02/05/2022</td>
      <td>27</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0.29</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.019</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0014</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Africa</td>
      <td>OWID_AFR</td>
      <td>03/05/2022</td>
      <td>27</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0.29</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.019</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0014</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Africa</td>
      <td>OWID_AFR</td>
      <td>04/05/2022</td>
      <td>27</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0.29</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.019</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0014</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Africa</td>
      <td>OWID_AFR</td>
      <td>05/05/2022</td>
      <td>27</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0.29</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.019</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0014</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
dt1.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 33666 entries, 0 to 33665
    Data columns (total 15 columns):
     #   Column                           Non-Null Count  Dtype  
    ---  ------                           --------------  -----  
     0   location                         33666 non-null  object 
     1   iso_code                         33666 non-null  object 
     2   date                             33666 non-null  object 
     3   total_cases                      33666 non-null  int64  
     4   total_deaths                     33666 non-null  int64  
     5   new_cases                        33666 non-null  int64  
     6   new_deaths                       33666 non-null  int64  
     7   new_cases_smoothed               33666 non-null  float64
     8   new_deaths_smoothed              33666 non-null  float64
     9   new_cases_per_million            33666 non-null  float64
     10  total_cases_per_million          33666 non-null  float64
     11  new_cases_smoothed_per_million   33666 non-null  float64
     12  new_deaths_per_million           33666 non-null  float64
     13  total_deaths_per_million         33666 non-null  float64
     14  new_deaths_smoothed_per_million  33666 non-null  float64
    dtypes: float64(8), int64(4), object(3)
    memory usage: 3.9+ MB
    


```python
correlation=dt1[['total_cases','total_deaths']].corr()
```


```python
print(correlation)
```

                  total_cases  total_deaths
    total_cases      1.000000      0.860625
    total_deaths     0.860625      1.000000
    


```python
Top_10_cases=dt1.groupby("location")["total_cases"].max().sort_values(ascending=False).head(10)
```


```python
Top_10_cases
```




    location
    World            87376
    North America    36958
    United States    30154
    Europe           25609
    South America    22336
    Brazil           10920
    Spain             7551
    France            4146
    Colombia          4090
    Mexico            4010
    Name: total_cases, dtype: int64




```python
Top_10_deaths=dt1.groupby("location")["total_deaths"].max().sort_values(ascending=False).head(10)
```


```python
Top_10_deaths
```




    location
    World            140
    North America     71
    South America     43
    United States     42
    Mexico            26
    Peru              20
    Africa            19
    Brazil            16
    Nigeria            9
    Europe             6
    Name: total_deaths, dtype: int64




```python
plt.figure(figsize=(12,6))
sns.barplot(x=Top_10_cases.index,y=Top_10_cases.values)
plt.title("Top 10 countries cases")
plt.xlabel("location")
plt.ylabel("Total Cases")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()
```


    
![png](output_24_0.png)
    



```python
plt.figure(figsize=(12,6))
sns.barplot(x=Top_10_deaths.index, y=Top_10_deaths.values)
plt.xlabel("countries")
plt.ylabel("No of deaths")
plt.title("Deaths per location")
plt.show()
```


    
![png](output_25_0.png)
    



```python
global_cases=dt1[dt1["location"]=="World"].set_index("date")["total_cases"]
```


```python
global_cases
```




    date
    01/05/2022       27
    02/05/2022       27
    03/05/2022       27
    04/05/2022       27
    05/05/2022       27
                  ...  
    05/05/2023    87365
    06/05/2023    87365
    07/05/2023    87376
    08/05/2023    87376
    09/05/2023    87376
    Name: total_cases, Length: 374, dtype: int64




```python
#visualising the changes of cases over time
plt.figure(figsize=(12,6))
plt.plot(global_cases.index,global_cases.values)
plt.xlabel("date")
plt.ylabel("total_cases")
plt.title("changes in total cases over time")
plt.show()
```


    
![png](output_28_0.png)
    



```python
dt1.columns
```




    Index(['location', 'iso_code', 'date', 'total_cases', 'total_deaths',
           'new_cases', 'new_deaths', 'new_cases_smoothed', 'new_deaths_smoothed',
           'new_cases_per_million', 'total_cases_per_million',
           'new_cases_smoothed_per_million', 'new_deaths_per_million',
           'total_deaths_per_million', 'new_deaths_smoothed_per_million'],
          dtype='object')




```python
#visualizing cases by continent
continents=["Africa","Asia","Europe","North America","South America","Oceania"]
```


```python
continent_cases=dt1[dt1['location'].isin(continents)].groupby('location')['total_cases'].max()
```


```python
continent_cases
```




    location
    Africa            1612
    Asia               673
    Europe           25609
    North America    36958
    Oceania            188
    South America    22336
    Name: total_cases, dtype: int64




```python
plt.figure(figsize=(12,6))
plt.title("cases by continents")
sns.barplot(x=continent_cases.index,y=continent_cases.values)
plt.xlabel("continent")
plt.ylabel("total cases")
plt.show()
```


    
![png](output_33_0.png)
    



```python
cases_per_million=dt1.groupby("location")["total_cases_per_million"].max().sort_values(ascending=False).head(10)
```


```python
cases_per_million
```




    location
    Gibraltar        183.615
    Spain            158.772
    Peru             111.602
    Portugal          92.787
    United States     89.137
    Luxembourg        88.017
    Monaco            82.212
    Colombia          78.845
    Chile             73.506
    Netherlands       71.965
    Name: total_cases_per_million, dtype: float64




```python
plt.figure(figsize=(12,6))
sns.barplot(x=cases_per_million.index,y=cases_per_million.values)
plt.title("10 countries cases per population")
plt.xlabel("countries")
plt.ylabel("No of cases")
plt.show()
```


    
![png](output_36_0.png)
    



```python
location_Africa= dt1[dt1["location"]=="Africa"]
```


```python
location_Africa.groupby("date").agg({"total_cases":"sum","total_deaths":"sum"}).plot(kind="line",figsize=(12,6))
```




    <Axes: xlabel='date'>




    
![png](output_38_1.png)
    



```python
dt1.columns
```




    Index(['location', 'iso_code', 'date', 'total_cases', 'total_deaths',
           'new_cases', 'new_deaths', 'new_cases_smoothed', 'new_deaths_smoothed',
           'new_cases_per_million', 'total_cases_per_million',
           'new_cases_smoothed_per_million', 'new_deaths_per_million',
           'total_deaths_per_million', 'new_deaths_smoothed_per_million'],
          dtype='object')




```python
#new_cases per million population overtime
dt1.groupby("date").agg({'new_cases_per_million':"sum",'new_deaths_per_million':"sum"}).plot(kind='line',figsize=(12,6))

```




    <Axes: xlabel='date'>




    
![png](output_40_1.png)
    



```python
dt1.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 33666 entries, 0 to 33665
    Data columns (total 15 columns):
     #   Column                           Non-Null Count  Dtype  
    ---  ------                           --------------  -----  
     0   location                         33666 non-null  object 
     1   iso_code                         33666 non-null  object 
     2   date                             33666 non-null  object 
     3   total_cases                      33666 non-null  int64  
     4   total_deaths                     33666 non-null  int64  
     5   new_cases                        33666 non-null  int64  
     6   new_deaths                       33666 non-null  int64  
     7   new_cases_smoothed               33666 non-null  float64
     8   new_deaths_smoothed              33666 non-null  float64
     9   new_cases_per_million            33666 non-null  float64
     10  total_cases_per_million          33666 non-null  float64
     11  new_cases_smoothed_per_million   33666 non-null  float64
     12  new_deaths_per_million           33666 non-null  float64
     13  total_deaths_per_million         33666 non-null  float64
     14  new_deaths_smoothed_per_million  33666 non-null  float64
    dtypes: float64(8), int64(4), object(3)
    memory usage: 3.9+ MB
    


```python
correlation_matrix=dt1.select_dtypes(include=['int64','float64']).corr()
correlation_matrix
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>total_cases</th>
      <th>total_deaths</th>
      <th>new_cases</th>
      <th>new_deaths</th>
      <th>new_cases_smoothed</th>
      <th>new_deaths_smoothed</th>
      <th>new_cases_per_million</th>
      <th>total_cases_per_million</th>
      <th>new_cases_smoothed_per_million</th>
      <th>new_deaths_per_million</th>
      <th>total_deaths_per_million</th>
      <th>new_deaths_smoothed_per_million</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>total_cases</th>
      <td>1.000000</td>
      <td>0.860625</td>
      <td>0.288652</td>
      <td>0.238052</td>
      <td>0.388820</td>
      <td>0.577087</td>
      <td>0.003547</td>
      <td>0.160672</td>
      <td>0.010644</td>
      <td>0.013670</td>
      <td>0.108732</td>
      <td>0.036349</td>
    </tr>
    <tr>
      <th>total_deaths</th>
      <td>0.860625</td>
      <td>1.000000</td>
      <td>0.098023</td>
      <td>0.244288</td>
      <td>0.133373</td>
      <td>0.588607</td>
      <td>-0.011543</td>
      <td>0.100795</td>
      <td>-0.026076</td>
      <td>0.026328</td>
      <td>0.248556</td>
      <td>0.069170</td>
    </tr>
    <tr>
      <th>new_cases</th>
      <td>0.288652</td>
      <td>0.098023</td>
      <td>1.000000</td>
      <td>0.130896</td>
      <td>0.781987</td>
      <td>0.168837</td>
      <td>0.127735</td>
      <td>0.013154</td>
      <td>0.105884</td>
      <td>0.010197</td>
      <td>-0.016544</td>
      <td>0.004257</td>
    </tr>
    <tr>
      <th>new_deaths</th>
      <td>0.238052</td>
      <td>0.244288</td>
      <td>0.130896</td>
      <td>1.000000</td>
      <td>0.094180</td>
      <td>0.432530</td>
      <td>0.006938</td>
      <td>0.032968</td>
      <td>0.001323</td>
      <td>0.375267</td>
      <td>0.065594</td>
      <td>0.146155</td>
    </tr>
    <tr>
      <th>new_cases_smoothed</th>
      <td>0.388820</td>
      <td>0.133373</td>
      <td>0.781987</td>
      <td>0.094180</td>
      <td>1.000000</td>
      <td>0.220016</td>
      <td>0.058329</td>
      <td>0.021636</td>
      <td>0.132268</td>
      <td>0.003392</td>
      <td>-0.020126</td>
      <td>0.006812</td>
    </tr>
    <tr>
      <th>new_deaths_smoothed</th>
      <td>0.577087</td>
      <td>0.588607</td>
      <td>0.168837</td>
      <td>0.432530</td>
      <td>0.220016</td>
      <td>1.000000</td>
      <td>-0.000731</td>
      <td>0.080387</td>
      <td>0.000233</td>
      <td>0.133181</td>
      <td>0.157210</td>
      <td>0.344301</td>
    </tr>
    <tr>
      <th>new_cases_per_million</th>
      <td>0.003547</td>
      <td>-0.011543</td>
      <td>0.127735</td>
      <td>0.006938</td>
      <td>0.058329</td>
      <td>-0.000731</td>
      <td>1.000000</td>
      <td>0.055787</td>
      <td>0.415639</td>
      <td>0.008775</td>
      <td>-0.013749</td>
      <td>0.001486</td>
    </tr>
    <tr>
      <th>total_cases_per_million</th>
      <td>0.160672</td>
      <td>0.100795</td>
      <td>0.013154</td>
      <td>0.032968</td>
      <td>0.021636</td>
      <td>0.080387</td>
      <td>0.055787</td>
      <td>1.000000</td>
      <td>0.142086</td>
      <td>0.030993</td>
      <td>0.239299</td>
      <td>0.082875</td>
    </tr>
    <tr>
      <th>new_cases_smoothed_per_million</th>
      <td>0.010644</td>
      <td>-0.026076</td>
      <td>0.105884</td>
      <td>0.001323</td>
      <td>0.132268</td>
      <td>0.000233</td>
      <td>0.415639</td>
      <td>0.142086</td>
      <td>1.000000</td>
      <td>0.004977</td>
      <td>-0.030020</td>
      <td>0.008848</td>
    </tr>
    <tr>
      <th>new_deaths_per_million</th>
      <td>0.013670</td>
      <td>0.026328</td>
      <td>0.010197</td>
      <td>0.375267</td>
      <td>0.003392</td>
      <td>0.133181</td>
      <td>0.008775</td>
      <td>0.030993</td>
      <td>0.004977</td>
      <td>1.000000</td>
      <td>0.108733</td>
      <td>0.378680</td>
    </tr>
    <tr>
      <th>total_deaths_per_million</th>
      <td>0.108732</td>
      <td>0.248556</td>
      <td>-0.016544</td>
      <td>0.065594</td>
      <td>-0.020126</td>
      <td>0.157210</td>
      <td>-0.013749</td>
      <td>0.239299</td>
      <td>-0.030020</td>
      <td>0.108733</td>
      <td>1.000000</td>
      <td>0.288544</td>
    </tr>
    <tr>
      <th>new_deaths_smoothed_per_million</th>
      <td>0.036349</td>
      <td>0.069170</td>
      <td>0.004257</td>
      <td>0.146155</td>
      <td>0.006812</td>
      <td>0.344301</td>
      <td>0.001486</td>
      <td>0.082875</td>
      <td>0.008848</td>
      <td>0.378680</td>
      <td>0.288544</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(12,6))
sns.heatmap(correlation_matrix, annot=True,cmap="coolwarm",linewidths=0.5)
plt.title("Correlation_matrix")
plt.show()
```


    
![png](output_43_0.png)
    



```python

```
